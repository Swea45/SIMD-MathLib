var searchData=
[
  ['usage_20example_0',['Usage Example',['../index.html#usage_sec',1,'']]]
];
