var searchData=
[
  ['example_0',['Usage Example',['../index.html#usage_sec',1,'']]]
];
