var searchData=
[
  ['library_0',['SIMD Math Library',['../index.html',1,'']]],
  ['license_1',['License',['../index.html#license_sec',1,'']]]
];
